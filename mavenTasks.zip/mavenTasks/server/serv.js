let express = require('express');
let app = express();
let jwt = require('jsonwebtoken');
let fs = require('fs');
let config = require('./config/conf');
let md5 = require('md5');
const passport = require('passport');
const bodyParser = require('body-parser');
const cors = require('cors');
app.use(cors());
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());
let port = 8081
app.get('/', function (req, res) {
    res.sendFile('/html/getAuthToken.html', {root: __dirname})
})
app.post('/getAuthToken', function (req, res) {
    let token = jwt.sign({id: req.body.email}, config.secret);
    // res.writeHead(200, { 'Content-Type': 'text/html' });
    // res.json({
    //     msg: "A new token is created",
    //     token: token
    // });
        res.write('<h1>Copy this code and go to postman and check </h1><br />');
        res.write('<h1>check put request using json format eg: {"counter":1000}</h1><br />');
        res.write(token);
        // res.write('<br /><a href="/check_api">Click Here</a>')
        res.end();
})
app.get('/check_api', verifyToken, function (req, res) {
    // console.log(req.headers)
    jwt.verify(req.token, config.secret, (err, authData) => {
        if (err) {
            res.sendStatus(403);
        } else {
            res.json({
                msg: "A new token is created",
                authData
            });
            // res.sendFile('/html/checkApi.html', {root: __dirname})
        }
    });

})
var userCount = 0;
app.get('/check_api/next', verifyToken, function (req, res) {
    jwt.verify(req.token, config.secret, (err, authData) => {
        if (err) {
            res.sendStatus(403);
        } else {
            let fName = authData.id.split('@')[0]
            const path = './counterDataUserWise/' + fName + '.txt'
            if (!fs.existsSync(path)) {
                //file exists
                fs.writeFileSync(path, userCount, 'utf8')
            }
            let lastCounter = fs.readFileSync(path, 'utf8')

            if (lastCounter === '') {
                fs.writeFileSync(path, userCount, 'utf8')
            } else {
                fs.writeFileSync(path, parseInt(lastCounter) + 1, 'utf8')
            }
            let readAgainCounter = fs.readFileSync(path, 'utf8')
            userCount++
            res.json({
                counter: parseInt(readAgainCounter) + 1
            });
        }
    });

})
app.get('/check_api/current', verifyToken, function (req, res) {
    jwt.verify(req.token, config.secret, (err, authData) => {
        if (err) {
            res.sendStatus(403);
        } else {
            let fName = authData.id.split('@')[0]
            let currentCounter = fs.readFileSync('./counterDataUserWise/' + fName + '.txt', 'utf8')
            res.json({
                currentCounter: currentCounter
            });
        }
    });
})
app.put('/check_api/current', verifyToken, function (req, res) {
    jwt.verify(req.token, config.secret, (err, authData) => {
        if (err) {
            res.sendStatus(403);
        } else {
            let fName = authData.id.split('@')[0];
            console.log(req.body)
            fs.writeFileSync('./counterDataUserWise/' + fName + '.txt', req.body.counter, 'utf8')
            res.json({
                msg: 'counter updated manually !!!!'
            });
        }
    });
})

function verifyToken(req, res, next) {

    //Request header with authorization key
    const bearerHeader = req.headers['authorization'];

    //Check if there is  a header
    if (typeof bearerHeader !== 'undefined') {
        const bearer = bearerHeader.split(' ');

        //Get Token arrray by spliting
        const bearerToken = bearer[1];
        req.token = bearerToken;
        //call next middleware
        next();
    } else {
        res.sendStatus(403);
    }
}

let server = app.listen(port, function () {
    let host = server.address().address
    console.log("Example app listening at http://localhost:" + port)
})